import starsmashertools
import math
import numpy as np
import copy


def flux_to_observer(
        output,
        n_res : int,
        min_value: float,
        max_value: float,
        xmin: float,
        xmax: float,
        ymin: float,
        ymax: float,
        do_domain: int,
        theta: float,
        phi: float,
        tau_s: float,
        tau_skip: float,
        teff_cut: float,
        do_fluffy:int,
        do_dust:int,
        test_ray: int = -1,
        itr: int = -1,
        jtr:int = -1,
        test_particle: int = -1,
        ic: int = -1,
):
    simulation = output.simulation
    
    do_rays=1
    
    # forming the spectrum
    # current assumption
    lmax=3000 #nm, stand for 1000K, no resolving below
    dl= 3. #nm resolution of boxes
    il_max=math.floor(lmax/dl)
    nbox=10 
    nboxh=5
    dl= dl*nbox #nm equialent width, in dl*nbox boxes
    spectrum=np.zeros(1000,dtype=float)
    lam=np.zeros(1000,dtype=float)
    b_l=np.zeros(1000,dtype=float)
    l_min=10 
    l_max=3000
    dl=10
    n_l=math.floor((l_max-l_min)/dl)+1
    nanom=1.e-7 # to convert from nanometer to CGS
    for j in range (0,n_l):
        lam[j]=(l_min+dl*j)*nanom

    spect_min=np.zeros(300000,dtype=int)
    spect_max=np.zeros(300000,dtype=int)
    spect_type=np.zeros(300000,dtype=int)
    print("Spectrum:", n_l, dl)
# for the Plank function integrations
#factor1=2.*h_const*c_speed*c_speed
#factor2=h_const*c_speed/(kb_const)
    factor1=1.191045e-05
    factor2=1.438728e+00
    
    # astronomical constants
    rsun=float(simulation.units.length)# 6.9599e10
    msun=float(simulation.units.mass) #1.9891e33
    c_speed=float(simulation.units.constants['c']) #2.99792458e10 #2.99e10
    a_const=float(simulation.units.constants['a']) #7.565767e-15 # cgs #7.5646e-15
    pi_const=math.pi
    sigma_const=float(simulation.units.constants['sigmaSB']) #5.6704e-5

    

    
    T_dust=1000.0
    T_dust_min=100.0
    kappa_dust=1.0

    time=0
    ltot=0
    l_v=0
    teff_aver=0
    rad_eff=0
    flag_return=1
    Lcool=0.
    Lheat=0.

    current = copy.deepcopy(output)
    current.rotate(xangle = theta, zangle = phi)
    
    # in case, to  ake sure we use the same units
    msun=float(simulation.units['am'])
    rsun=float(simulation.units['x'])
    
    ntot = current['ntot']
    time=current['t'] * simulation.units['t']
    rho = current['rho'] * float(simulation.units['rho'])
    m = current['am']
    h = current['hp']
    rho = current['rho'] * float(simulation.units['rho'])
    u = current['u'] * float(simulation.units['u'])
    uraddot = current['uraddot'] * float(simulation.units['uraddot'])
    uraddotcool = current['uraddotcool'] * float(simulation.units['uraddotcool'])
    uraddotheat = current['uraddotheat'] * float(simulation.units['uraddotheat'])
    uraddot_emerg = current['dEemergdt'] * float(simulation.units['dEemergdt'])
    uraddot_diff = current['dEdiffdt'] * float(simulation.units['dEdiffdt'])
    kappa = current['popacity'] * float(simulation.units['popacity'])
    tau = current['tau']
    temp = current['temperatures']    
    rloc=np.zeros(ntot, dtype=float) #current['x']
    x=current['x']
    y=current['y']
    z=current['z']
    id=current['ID']

    #======

    print("min_value: %12.5f" % min_value)
    print("max_value: %12.5f" % max_value)

    if do_domain != 1:
        print("xmin: %12.5f" % xmin)
        print("xmax: %12.5f" % xmax)
        print("ymin: %12.5f" % ymin)
        print("ymax: %12.5f" % ymax)

    if do_domain == 1:
        rloc_arr = (0.75*m*msun/(pi_const*rho))**0.33333/rsun
        if do_fluffy == 1:
            rloc_arr = 2.*h
        xmin = np.amin(x - rloc_arr)
        xmax = np.amax(x + rloc_arr)
        ymin = np.amin(y - rloc_arr)
        ymax = np.amax(y + rloc_arr)

        max_coord=max(abs(xmin),abs(xmax), abs(ymin), abs(ymax))
        xmax=max_coord
        ymax=max_coord
        ymin=-max_coord
        xmin=-max_coord    
        print("domain  max: %12.5f" %  max_coord)


    ltot=0.
    l_v=0.
    l_ir=0.

    print("Time = %4f" % time)

    rows=n_res
    cols=n_res

    surf_d = np.zeros((rows,cols))
    surf_id = np.zeros((rows,cols),dtype=int)
    surf_br = np.zeros((rows,cols))
    surf_br_v = np.zeros((rows,cols))
    surf_t = np.zeros((rows,cols))
    flux=np.zeros(300000)
    teff=np.zeros(300000)
    ray_id =  np.zeros((rows,cols,600),dtype=int)
    ray_n =  np.zeros((rows,cols),dtype=int)

    for i in range(0,n_res-1):
        for j in range(0,n_res-1):
            surf_id[i][j]=-1
            surf_d[i][j]=-1.e30
            surf_t[i][j]=0.

    dx = (xmax-xmin)/(n_res-1)
    dy = (ymax-ymin)/(n_res-1)

    print("dx=%f dy=%f"%(dx,dy))
    
    Lcool=0.
    Lheat=0.
    Lurad=0.
    t_max=0.
        
    for i in range(1, ntot-1):

        iloc = math.floor((x[i]-xmin)/dx)
        jloc = math.floor((y[i]-ymin)/dy)

        #if temp[i] < T_dust and temp[i] > T_dust_min:
            #print("cold particle opacity",temp[i],kappa[i])
            
        if temp[i] < T_dust and temp[i] > T_dust_min and kappa[i] < kappa_dust and do_dust == 1:
            kappa[i]=kappa_dust
            
        if uraddot_emerg[i] < uraddot_diff[i] and do_fluffy == 1:
            # this particle is considered in "fluffy" approximation
            rloc[i]=2.*h[i]
            rhoold=rho[i]
            rho[i]=m[i]*msun/pow(rloc[i]*rsun,3.)
            #kappa[i]=kappa[i]*rho[i]/rhoold
            #if temp[i] < 1000 and kappa[i] < 1 and do_dust == 1:
            #    kappa[i]=1.0
            tau[i]=rho[i]*kappa[i]*rloc[i]*rsun*4./3.
            flux_em = uraddot_emerg[i]/4./pi_const/rloc[i]/rloc[i]/rsun/rsun
            flux[i]=flux_em
            flux_rad=flux_em
            #print("Treat fluffy %d %f %f %f %f %f"%(i, kappa[i], temp[i], tau[i], flux[i], rloc[i]))           
 
        else :
            # this particle is considered in "dense" approximation 
            rloc[i]=pow(m[i]*msun/(4/3.*pi_const)/rho[i],0.33333)/rsun
            tau[i]=rho[i]*kappa[i]*rloc[i]*rsun*4./3.
            ad      = 4.*pi_const*rloc[i]*rloc[i]*rsun*rsun
            ad_cool = 2.*pi_const*rloc[i]*rloc[i]*rsun*rsun
            flux_em = uraddot_emerg[i]/ad
            dd=c_speed/kappa[i]/rho[i]
            tdiffloc=kappa[i]*rho[i]*rloc[i]*rloc[i]*rsun*rsun/c_speed
            gradt=a_const*pow(temp[i],4)/rloc[i]/rsun
            dedt=ad/3.*dd*gradt/m[i]/msun
            flux[i]=dedt*m[i]*msun/ad
            flux_rad=dedt*m[i]*msun/ad
            flux_cool=-uraddotcool[i]*m[i]*msun/ad
            ratio = -uraddotcool[i]/dedt*12. # to figure out how many effective cooling rays
            if do_rays == 1:
                if ratio <= 6: # all what is cooling it, goes through the outer hemisphere
                    flux[i]=-uraddotcool[i]*m[i]*msun/ad_cool # all what is cooled is to goes through the outer hemisphere
                if ratio > 6: # the particle is getting cooled also to the back, but cools at max through the outer hemisphere
                    flux[i]=dedt*m[i]*msun/ad

            if id[i] == 54996:
                print(" trace  %10.4e  %10.4e %10.4e %10.4e %10.4e %10.4e %10.4e %6f"%(uraddot_emerg[i], uraddot_diff[i], uraddot_diff[i]/uraddot_emerg[i], flux_em, flux[i], flux_cool,flux[i]/flux_em, ratio))

            if tau[i] < 100:
                flux[i]=min(flux[i],flux_em)
            #if min(uraddot_emerg[i],uraddot_diff[i]) > 1.e36:
            #    conv=4.*pi_const*rsun*rsun*rloc[i]*rloc[i]/lsun
            #    flag_diff=0
            #    if uraddot_emerg[i] > uraddot_diff[i]:
            #        flag_diff=1
            #    print("Energies %d %d em=%10.4e diff=%10.4e tot=%10.4e fc=%10.4e flux=%10.4e  tau=%10.4e  ratio=%4f"%(id[i], flag_diff, uraddot_emerg[i]/lsun,uraddot_diff[i]/lsun, uraddotcool[i]*m[i]*msun/lsun/conv,flux_cool, flux[i],tau[i], ratio))

        teff[i]=pow(flux_rad/sigma_const,0.25)
        spect_type[i]=1 # black body
        if flux_rad > flux_em and tau[i] < 100:
            teff[i]=temp[i]
            spect_type[i]=2  # emerging
        lam_max = 2.9*1000000./teff[i]
        i_lam=math.floor(lam_max/3.)
        i_lam=i_lam-nboxh
        i_lam= max(i_lam,0)
        i_lam= min(i_lam,il_max-1-nbox)
        spect_min[i]=i_lam
        spect_max[i]=i_lam+nbox


        #if spect_type[i] == 1 and teff[i]> 50000:
        #    print(temp[i], teff[i], tau[i], spect_type[i], spect_min[i], spect_max[i])


        if i == ic and test_particle==1:
            print("%d z=%8.4e in [%8.4e; %8.4e] %8.4e "% (i, z[i], z[i]-rloc, z[i]+rloc[i], tau[i]))

        if iloc >= 0 and iloc <= (n_res-1) and jloc >=0 and jloc <=(n_res-1):
            if tau[i] >=  tau_s and z[i] > surf_d[iloc][jloc] :

                imin = max(math.floor((x[i]-rloc[i]-xmin)/dx),0)
                imax = min(math.ceil((x[i]+rloc[i]-xmin)/dx),n_res-1)
                jmin = max(math.floor((y[i]-rloc[i]-ymin)/dy),0)
                jmax = min(math.ceil((y[i]+rloc[i]-ymin)/dy), n_res-1)
                
                for ii in range(imin,imax):
                    for jj in range(jmin,jmax):
                        xloc=xmin+dx*ii
                        yloc=ymin+dy*jj
                        dist=pow( (xloc-x[i])*(xloc-x[i])+(yloc-y[i])*(yloc-y[i]),0.5)
                        if test_ray == 1 and ii==itr and jj==jtr:
                            print("consider ray to %d %d  id=%d z=%8.4e tau=%8.4e    %e %e"%(itr,jtr,surf_id[itr][jtr],surf_d[itr][jtr],tau[surf_id[itr][jtr]], xloc,yloc))
                        
                        if z[i] > surf_d[ii][jj] and dist <= rloc[i]:
                            surf_d[ii][jj]=z[i]
                            surf_id[ii][jj]=i



    if test_ray == 1:
        print("created a ray to %d %d  id=%d z=%8.4e tau=%8.4e    %e %e"%(itr,jtr,surf_id[itr][jtr],surf_d[itr][jtr],tau[surf_id[itr][jtr]], xmin+dx*itr,ymin+dy*jtr))
        #exit()

    tau_min=1

    for i in range(0, ntot-1):

        iloc = math.floor((x[i]-xmin)/dx)
        jloc = math.floor((y[i]-ymin)/dy)

        if i == ic and test_particle==1:
            print("CHECK 0 %d %d %d z=%8.4e in [%8.4e; %8.4e] x=%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e %d"% (i, iloc, jloc, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[iloc][jloc], z[surf_id[iloc][jloc]], surf_id[iloc][jloc]))

        if iloc >= 0 and iloc <= (n_res-1) and jloc >=0 and jloc <=(n_res-1) :

            imin = max(math.floor((x[i]-rloc[i]-xmin)/dx),0)
            imax = min(math.ceil((x[i]+rloc[i]-xmin)/dx),n_res-1)
            jmin = max(math.floor((y[i]-rloc[i]-ymin)/dy),0)
            jmax = min(math.ceil((y[i]+rloc[i]-ymin)/dy), n_res-1)
            
            if i == ic and test_particle==1:
                print("CHECK 1 %d %d %d %d %d z=%8.4e in [%8.4e; %8.4e] x==%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e"% (i, imin, imax, jmin, jmax, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[ii][jj], z[surf_id[ii][jj]]))
                
            for ii in range(imin,imax):
                for jj in range(jmin,jmax):
                    xloc=xmin+dx*ii
                    yloc=ymin+dy*jj
                    dist=pow( (xloc-x[i])*(xloc-x[i])+(yloc-y[i])*(yloc-y[i]),0.5)
                    if i == ic and test_particle==1:
                        print("CHECK 2 %d %d %d z=%8.4e in [%8.4e; %8.4e] x==%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e"% (i, ii, jj, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[ii][jj], z[surf_id[ii][jj]]))
                    if z[i] > surf_d[ii][jj] and dist <= rloc[i] and tau[i] >= tau_skip:
                        ray_id[ii][jj][ray_n[ii][jj]]=i
                        ray_n[ii][jj]=ray_n[ii][jj]+1
                        if tau[i] < tau_min:
                            tau_min=tau[i]
                        if ii == itr and jj==jtr and test_ray==1:
                            print("adding a ray to %d %d  count=%d  %d tau=%8.4e"%(ii,jj,ray_n[ii][jj],i,tau[i]))

    max_ray=0
    i_maxray=0
    j_maxray=0
    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            if ray_n[ii][jj] > max_ray:
                max_ray=ray_n[ii][jj]
                i_maxray=ii
                j_maxray=jj

    print("maximum number of particles above the cut off optically thick surface is %d %d %d"%(max_ray,i_maxray,j_maxray))            
    print("minimum tau account for is  is %f"%(tau_min))            


    # this sorting is as simple as hell 
    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            if ray_n[ii][jj] > 1:
                #print("ray as %d %d  r_max=%d surface=%8.4e"%(ii,jj,ray_n[ii][jj],surf_d[ii][jj]))
                for kk in range(0, ray_n[ii][jj]):
                    swap=0
                    for ri in range(0, ray_n[ii][jj]-1):
                        ir1=ray_id[ii][jj][ri]
                        ir2=ray_id[ii][jj][ri+1]
                        if ir1==0 or ir2 ==0:
                            print("ray to the core? %d %d", ii, jj)
                            exit()
                        if z[ir1] > z[ir2]:
                            ray_id[ii][jj][ri]=ir2
                            ray_id[ii][jj][ri+1]=ir1
                            swap=swap+1
                    if swap == 0:
                        break
                if swap > 0:
                    print("Did not complete sorting")
                    exit()


    if test_ray == 1:
        print("ray outwards")  
        print("surface at %d %d   id=%d  z=%e"%(itr,jtr,surf_id[itr][jtr], z[surf_id[itr][jtr]]))
        if ray_n[itr][jtr] > 0:      
            for ri in range(0, ray_n[itr,jtr]):                
                print("ray at %d %d  id=%d  number of rays %d"%(itr,jtr,ray_id[itr][jtr][ri],ray_n[itr,jtr]))
                print("ray backwards")  
        if ray_n[itr][jtr] > 0:      
            for ri in range(ray_n[itr,jtr]-1, -1, -1):
                print("ray at %d %d  id=%d"%(itr,jtr,ray_id[itr][jtr][ri]))
                print("surface at %d %d   id=%d  number of rays %d"%(itr,jtr,surf_id[itr][jtr],ray_n[itr,jtr]))

    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            i=surf_id[ii][jj]
            surf_br_v[ii][jj] = 0
            surf_br[ii][jj] = 0            
            tau_ray=0.    
            if ray_n[ii][jj] > 0:
                #print("ray as %d %d  r_max=%d surface=%8.4e"%(ii,jj,ray_n[ii][jj],surf_d[ii][jj]))
                for ri in range(ray_n[ii,jj]-1, -1, -1):
                    ir = ray_id[ii,jj][ri]
                    surf_br[ii,jj] += flux[ir] * np.exp(-tau_ray)
                    if t_max < teff[ir] :
                        t_max=teff[ir]
                        
#                    for il in range (5):
#                        ill=il+spect_min[ir]
#                        spectrum[ill]=spectrum[ill]+flux[ir] * np.exp(-tau_ray) / dl
                    for j in range (0,n_l):
                        expon=factor2/teff[ir]/lam[j]
                        b_full= sigma_const/pi_const*pow(teff[ir],4.)
                        if expon < 150:
                            b_l[j] = factor1/pow(lam[j],5.)/(math.exp(expon)-1.0)
                        else:
                            b_l[j] = 0.
                        spectrum[j]=spectrum[j]+flux[ir] * np.exp(-tau_ray) * (b_l[j] / b_full)   
                            
                        
                    if test_ray == 1 and ii==itr and jj==jtr:
                        print("brigntess modification backward %d  br=%e flux_loc=%e tau_t=%e tau_l=%e   z=%e in [%e,%e] x=%e y=%e"%(ir, surf_br[ii,jj],flux[ir],tau_ray,tau[ir],z[ir],z[ir]-4./3.*h[ir],z[ir]+4./3.*h[ir], x[ir],y[ir]))
                        
                    if teff[ir] > teff_cut:
                        surf_br_v[ii][jj]+=flux[ir] * np.exp(-tau_ray)
                        
                    tau_ray += tau[ir]           

                    if surf_br_v[ii][jj] >  surf_br[ii][jj]:
                        print("part of the flux is larger then whole flux?   %d %d %d %d   tau=%8.4e  %8.4e  %8.4e  %8.4e"%(ii,jj,ri,ir,tau[ir],surf_br[ii][jj],surf_br_v[ii][jj],flux[ir]))
                        exit()

            i=surf_id[ii][jj]
            if i > 0:
                surf_br[ii,jj] += flux[i] * np.exp(-tau_ray)
                
                for j in range (0,n_l):
                    expon=factor2/teff[i]/lam[j]
                    b_full= sigma_const/pi_const*pow(teff[i],4.)
                    if expon < 150:
                        b_l[j] = factor1/pow(lam[j],5.)/(math.exp(expon)-1.0)
                    else:
                        b_l[j] = 0.
                        
                    spectrum[j]=spectrum[j]+flux[i] * np.exp(-tau_ray) * (b_l[j] / b_full)   
                
                if test_ray == 1 and ii==itr and jj==jtr:
                    print("brigntess modification finishes at %d %e %e %e  tau_tot=%e   z=%e in [%e;%e]  x=%e y=%e"%(i, surf_br[ii,jj],flux[i],tau_ray,tau[i],z[i],z[i]-4./3.*h[i],z[i]+4./3.*h[i],x[i],y[i]))
                    
                if teff[i] > teff_cut:
                    surf_br_v[ii][jj] += flux[i]* np.exp(-tau_ray)

    print("rays sorting is completed")
    print("maximum observed Teff", t_max)

            
    if test_ray == 1:
        print("final brigntess %e "%(surf_br[itr,jtr]))

    flux_tot=0.
        
    for ii in range(0,n_res-2):
        for jj in range(0,n_res-2):
            area_br = (surf_br[ii][jj] + surf_br[ii][jj+1] + surf_br[ii+1][jj] + surf_br[ii+1][jj+1])/4.
            
            teff_loc = pow(area_br/sigma_const,0.25)
            
            surf_t[ii][jj]=teff_loc*area_br            
            #if teff_loc > 4000:
            #    print("check local T=%e  flux=%e"%(teff_loc, area_br))

            flux_tot=flux_tot+area_br   
            ltot=ltot+area_br
            l_v=l_v+surf_br_v[ii][jj]

                
    teff_aver=0.
    for ii in range(0,n_res-2):
        for jj in range(0,n_res-2):
            surf_t[ii][jj]=surf_t[ii][jj]/ltot
            teff_aver=teff_aver+surf_t[ii][jj]

            
    #sp_file=open("spectrum.dat","w")
    
    teff_spectrum=0.
    max_flux=0.
    ltot_spectrum=0.
    lv_spectrum=0.
    lr_spectrum=0.
    l_spectrum = {'V':0, 'R':0}
    for il in range (il_max-1):
        sp=spectrum[il]
        ltot_spectrum=ltot_spectrum+spectrum[il]*dl*nanom
        if sp > 1:
            sp=np.log10(sp)
            lamb=lam[il]/nanom
            teff_loc= 2.9*1.e6/lamb
            if sp > max_flux:
                max_flux=sp
                teff_spectrum=teff_loc
            if lamb >= 507 and lamb <=595:
                lv_spectrum=lv_spectrum+spectrum[il]*dl*nanom
                l_spectrum['V'] += spectrum[il]*dl*nanom
            if lamb >= 589 and lamb <=727:
                lr_spectrum=lr_spectrum+spectrum[il]*dl*nanom
                l_spectrum['R'] += spectrum[il]*dl*nanom
                
    b_full= sigma_const/pi_const*pow(teff_spectrum,4.)
    spectrum_output = []
    for il in range (il_max-1):
        sp=spectrum[il]
        if sp > 1:
            sp=np.log10(sp)
            lamb=lam[il]/nanom
            teff_loc= 2.9*1.e6/lamb
            expon=factor2/teff_spectrum/lam[il]
            if expon < 150:
                b_l[il] = factor1/pow(lam[il],5.)/(math.exp(expon)-1.0)
            else:
                b_l[il] = 0.
            spectrum_output += [[il, lamb, teff_loc, sp, b_l[il]]]
            #print(il, lamb, teff_loc,sp,b_l[il], file=sp_file)
            
            
    #sp_file.flush()


    #teff_aver= (flux_tot / sigma_const)**0.25
    
    print("Total flux=%le ltot=%le "%(flux_tot,ltot))
    print("Averagef Teff=%le   non-aver= %le  Spectrum teff"%(teff_aver,pow(flux_tot/sigma_const,0.25)),teff_spectrum)
            
    ltot=ltot*dx*dy*rsun*rsun
    l_v=l_v*dx*dy*rsun*rsun
    ltot_spectrum=4 * ltot_spectrum*dx*dy*rsun*rsun
    for key, val in l_spectrum.items():
        l_spectrum[key] = 4 * val * dx * dy * rsun**2
    lv_spectrum=lv_spectrum*dx*dy*rsun*rsun
    lr_spectrum=lr_spectrum*dx*dy*rsun*rsun
    print("Check luminosities ltot=%le ltot_spectrum=%le "%(ltot,ltot_spectrum))
    
    Lcool=0.
    Lheat=0.
    Lurad=0.
    for i in range(1,ntot,1):
        Lcool=Lcool+uraddotcool[i]*m[i]
        Lheat=Lheat+uraddotheat[i]*m[i]
        Lurad=Lurad+uraddot[i]*m[i]
    
    print("Total L %12.4E "% (ltot*4.))
    print("V L %12.4E %12.4E "% (l_v*4.,lv_spectrum*4.))
    print("R L %12.4E %12.4E "% (l_v*4.,lr_spectrum*4.))
    print("Cooling L %12.4E "% (Lcool*msun))
    print("Heating L %12.4E "% (Lheat*msun))
    print("udot L %12.4E "% (Lurad*msun))

    #teff_aver=teff_spectrum
    #l_v=lv_spectrum
    #l_r=lr_spectrum
    rad_eff = pow(ltot*4./pi_const/sigma_const/pow(teff_spectrum,4),0.5)/rsun
    print("Effective radius %e"%rad_eff)
    return [time,(ltot*4.),(l_v*4.),(lr_spectrum*4.),teff_aver,teff_spectrum,rad_eff,surf_br,surf_br_v,surf_d,surf_id,surf_t,ray_n,dx,dy,flux_tot,spectrum_output,xmin,xmax,ymin,ymax,ltot_spectrum,l_spectrum,flux,teff,kappa,tau,rloc]
 

    ###
    ###

    
