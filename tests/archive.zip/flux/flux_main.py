import math
import sys, getopt
import numpy as np
import copy


def flux_to_observer(
        output,
        n_res : int
            , min_value: float
            , max_value: float
            , xmin: float, xmax: float
            , ymin: float, ymax: float
            , do_domain: int
            , theta: float, phi: float
            , tau_s: float, tau_skip: float
            , do_fluffy:int, do_dust:int
            , test_ray: int = -1, itr: int = -1, jtr:int = -1
            , test_particle: int = -1, ic: int = -1
            ):

    simulation = output.simulation

    do_rays=1
    
    # forming the spectrum
    # current assumption
    lmax=3000 #nm, stand for 1000K, no resolving below
    dl= 3. #nm resolution of boxes
    il_max=math.floor(lmax/dl)
    nbox=10 
    nboxh=5
    dl= dl*nbox #nm equialent width, in dl*nbox boxes
    spectrum=np.zeros(1000,dtype=float)
    lam=np.zeros(1000,dtype=float)
    b_l=np.zeros(1000,dtype=float)
    l_min=10 
    l_max=3000
    dl=10
    n_l=math.floor((l_max-l_min)/dl)+1
    nanom=1.e-7 # to convert from nanometer to CGS
    for j in range (0,n_l):
        lam[j]=(l_min+dl*j)*nanom 

    
    print("Spectrum:", n_l, dl)
# for the Plank function integrations
#factor1=2.*h_const*c_speed*c_speed
#factor2=h_const*c_speed/(kb_const)
    factor1=1.191045e-05
    factor2=1.438728e+00

    # astronomical constants
    rsun=float(simulation.units.length)# 6.9599e10
    msun=float(simulation.units.mass) #1.9891e33
    c_speed=float(simulation.units.constants['c']) #2.99792458e10 #2.99e10
    a_const=float(simulation.units.constants['a']) #7.565767e-15 # cgs #7.5646e-15
    pi_const=math.pi
    sigma_const=float(simulation.units.constants['sigmaSB']) #5.6704e-5

    

    
    T_dust=1000.0
    T_dust_min=100.0
    kappa_dust=1.0

    time=0
    ltot=0
    l_v=0
    teff_aver=0
    rad_eff=0
    flag_return=1
    Lcool=0.
    Lheat=0.

    #===== common initializing/data file reading part 
    current = copy.deepcopy(output)
    simulation = output.simulation
    
    # in case, to  ake sure we use the same units
    msun=float(simulation.units['am'])
    rsun=float(simulation.units['x'])
    
    ntot = current['ntot']
    time=current['t'] * simulation.units['t']
    rho = current['rho'] * float(simulation.units['rho'])
    m = current['am']
    h = current['hp']
    rho = current['rho'] * float(simulation.units['rho'])
    u = current['u'] * float(simulation.units['u'])
    uraddot = current['uraddot'] * float(simulation.units['uraddot'])
    uraddotcool = current['uraddotcool'] * float(simulation.units['uraddotcool'])
    uraddotheat = current['uraddotheat'] * float(simulation.units['uraddotheat'])
    uraddot_emerg = current['dEemergdt'] * float(simulation.units['dEemergdt'])
    uraddot_diff = current['dEdiffdt'] * float(simulation.units['dEdiffdt'])
    kappa = current['popacity'] * float(simulation.units['popacity'])
    tau = current['tau']
    temp = current['temperatures']    
    rloc=np.zeros(ntot, dtype = float)
    x=current['x']
    y=current['y']
    z=current['z']
    vx=current['vx']* float(simulation.units['vx'])/1.e5
    vy=current['vy']* float(simulation.units['vy'])/1.e5
    vz=current['vz']* float(simulation.units['vx'])/1.e5
    id=current['ID']

    #======

    x,y,z = rotate(x,y,z,-theta,0,-phi)
    
    theta_rot = float(-theta)/180.*np.pi    
    for i in range(0,ntot-1):
        v=np.sqrt(vx[i]*vx[i] + vy[i]*vy[i] + vz[i]*vz[i])
        if theta_rot > 0: # rotate about x
            vz_old=vz[i]
            uz = vy[i]*np.sin(theta_rot)+vz[i]*np.cos(theta_rot)
            vz[i] = uz


    
    print("min_value: %12.5f" % min_value)
    print("max_value: %12.5f" % max_value)

    if do_domain != 1:
        print("xmin: %12.5f" % xmin)
        print("xmax: %12.5f" % xmax)
        print("ymin: %12.5f" % ymin)
        print("ymax: %12.5f" % ymax)

    if do_domain == 1:
        rloc_arr = (0.75*m*msun/(pi_const*rho))**0.33333/rsun
        if do_fluffy == 1:
            rloc_arr = 2.*h
        xmin = np.amin(x - rloc_arr)
        xmax = np.amax(x + rloc_arr)
        ymin = np.amin(y - rloc_arr)
        ymax = np.amax(y + rloc_arr)

        max_coord=max(abs(xmin),abs(xmax), abs(ymin), abs(ymax))
        print("domain  max: %12.5f" %  max_coord)
        #max_coord=min(max_coord, 2000)
        xmax=max_coord
        ymax=max_coord
        ymin=-max_coord
        xmin=-max_coord    
        print("domain  max: %12.5f" %  max_coord)


    ltot=0.

    print("Time = %4f" % time)
    plot_title =  "Time = " +format(time, '4.1f') + " days"
    print("Doing plot titles %s" % plot_title)

    rows=n_res
    cols=n_res

    surf_d = np.zeros((rows,cols))
    surf_id = np.zeros((rows,cols),dtype=int)
    surf_br = np.zeros((rows,cols))

    surf_t = np.zeros((rows,cols))
    flux=np.zeros(300000)
    teff=np.zeros(300000)
    ray_id =  np.zeros((rows,cols,600),dtype=int)
    ray_n =  np.zeros((rows,cols),dtype=int)

    for i in range(0,n_res-1):
        for j in range(0,n_res-1):
            surf_id[i][j]=-1
            surf_d[i][j]=-1.e30
            surf_t[i][j]=0.

    dx = (xmax-xmin)/(n_res-1)
    dy = (ymax-ymin)/(n_res-1)

    print("dx=%f dy=%f"%(dx,dy))
    
    Lcool=0.
    Lheat=0.
    Lurad=0.
    t_max=0.
    vel_flux=0.
        
    for i in range(1, ntot-1):

        iloc = math.floor((x[i]-xmin)/dx)
        jloc = math.floor((y[i]-ymin)/dy)

        #if temp[i] < T_dust and temp[i] > T_dust_min:
        #    print("cold particle opacity",temp[i],kappa[i])
            
        if temp[i] < T_dust and temp[i] > T_dust_min and kappa[i] < kappa_dust and do_dust == 1:
            kappa[i]=kappa_dust
            
        if uraddot_emerg[i] < uraddot_diff[i] and do_fluffy == 1:
            # this particle is considered in "fluffy" approximation
            rloc[i]=2.*h[i]
            rhoold=rho[i]
            rho[i]=m[i]*msun/pow(rloc[i]*rsun,3.)
            #kappa[i]=kappa[i]*rho[i]/rhoold
            #if temp[i] < 1000 and kappa[i] < 1 and do_dust == 1:
            #    kappa[i]=1.0
            tau[i]=rho[i]*kappa[i]*rloc[i]*rsun*4./3.
            flux_em = uraddot_emerg[i]/4./pi_const/rloc[i]/rloc[i]/rsun/rsun
            flux[i]=flux_em
            flux_rad=flux_em
            #print("Treat fluffy %d %f %f %f %f %f"%(i, kappa[i], temp[i], tau[i], flux[i], rloc[i]))           
 
        else :
            # this particle is considered in "dense" approximation 
            rloc[i]=pow(m[i]*msun/(4/3.*pi_const)/rho[i],0.33333)/rsun
            tau[i]=rho[i]*kappa[i]*rloc[i]*rsun*4./3.
            ad      = 4.*pi_const*rloc[i]*rloc[i]*rsun*rsun
            ad_cool = 2.*pi_const*rloc[i]*rloc[i]*rsun*rsun
            flux_em = uraddot_emerg[i]/ad
            
            dd=c_speed/kappa[i]/rho[i]
            tdiffloc=kappa[i]*rho[i]*rloc[i]*rloc[i]*rsun*rsun/c_speed
            gradt=a_const*pow(temp[i],4)/rloc[i]/rsun
            dedt=ad/3.*dd*gradt/m[i]/msun
            
            flux_rad = dedt*m[i]*msun/ad
            ratio = abs(-uraddotcool[i]/dedt*12.) # to figure out how many effective cooling rays
            flux[i]  = dedt*m[i]*msun/ad
            
            if do_rays == 1:
                if ratio <= 6: # all what is cooling it, goes through the outer hemisphere
                    flux[i]=abs(-uraddotcool[i]*m[i]*msun/ad_cool) # all what is cooled is to goes through the outer hemisphere
                if ratio > 6: # the particle is getting cooled also to the back, but cools at max through the outer hemisphere
                    flux[i]=dedt*m[i]*msun/ad

            if tau[i] < 100: # we anticipate that emergent flux computation breaks down at very large tau, where flux_em becomes zero and nullifies total flux is no limit on tau is placed
                flux[i]=min(flux[i],flux_em)

            #if tau[i] >= 100 and flux_em > flux_rad:
            #    print("Check high tau particles", i, tau[i], flux_rad, flux_em, flux[i], ratio,uraddotcool[i])
                
            
########### NATA: ATTENTION, CHECK WHAT ROGER HAS. tau has to have the same cut off as in the above condition
        teff[i]=pow(flux_rad/sigma_const,0.25)     
        if flux_rad > flux_em and tau[i] < 100:
            teff[i]=temp[i]
            
        if i == ic and test_particle==1:
            print("%d z=%8.4e in [%8.4e; %8.4e] %8.4e "% (i, z[i], z[i]-rloc, z[i]+rloc[i], tau[i]))


        if iloc >= 0 and iloc <= (n_res-1) and jloc >=0 and jloc <=(n_res-1):
            if tau[i] >=  tau_s and z[i] > surf_d[iloc][jloc] :

                imin = max(math.floor((x[i]-rloc[i]-xmin)/dx),0)
                imax = min(math.ceil((x[i]+rloc[i]-xmin)/dx),n_res-1)
                jmin = max(math.floor((y[i]-rloc[i]-ymin)/dy),0)
                jmax = min(math.ceil((y[i]+rloc[i]-ymin)/dy), n_res-1)

                for ii in range(imin,imax):
                    for jj in range(jmin,jmax):
                        xloc=xmin+dx*ii
                        yloc=ymin+dy*jj
                        dist=pow( (xloc-x[i])*(xloc-x[i])+(yloc-y[i])*(yloc-y[i]),0.5)
                        
                        if z[i] > surf_d[ii][jj] and dist <= rloc[i]:
                            surf_d[ii][jj]=z[i]
                            surf_id[ii][jj]=i
                            
                        if test_ray == 1 and ii==itr and jj==jtr:
                            print("consider ray to %d %d  id=%d z=%8.4e tau=%8.4e    %e %e"%(itr,jtr,surf_id[itr][jtr],surf_d[itr][jtr],tau[surf_id[itr][jtr]], xloc,yloc))
                        


    if test_ray == 1:
        print("created a ray to %d %d  id=%d z=%8.4e tau=%8.4e    %e %e"%(itr,jtr,surf_id[itr][jtr],surf_d[itr][jtr],tau[surf_id[itr][jtr]], xmin+dx*itr,ymin+dy*jtr))
        #exit()

    tau_min=1
    flux_min=1.e12
    flux_max=0

    for i in range(0, ntot-1):

        iloc = math.floor((x[i]-xmin)/dx)
        jloc = math.floor((y[i]-ymin)/dy)

        if i == ic and test_particle==1:
            print("CHECK 0 %d %d %d z=%8.4e in [%8.4e; %8.4e] x=%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e %d"% (i, iloc, jloc, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[iloc][jloc], z[surf_id[iloc][jloc]], surf_id[iloc][jloc]))

        if iloc >= 0 and iloc <= (n_res-1) and jloc >=0 and jloc <=(n_res-1) :

            imin = max(math.floor((x[i]-rloc[i]-xmin)/dx),0)
            imax = min(math.ceil((x[i]+rloc[i]-xmin)/dx),n_res-1)
            jmin = max(math.floor((y[i]-rloc[i]-ymin)/dy),0)
            jmax = min(math.ceil((y[i]+rloc[i]-ymin)/dy), n_res-1)
            
            if i == ic and test_particle==1:
                print("CHECK 1 %d %d %d %d %d z=%8.4e in [%8.4e; %8.4e] x==%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e"% (i, imin, imax, jmin, jmax, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[ii][jj], z[surf_id[ii][jj]]))
                
            for ii in range(imin,imax):
                for jj in range(jmin,jmax):
                    xloc=xmin+dx*ii
                    yloc=ymin+dy*jj
                    dist=pow( (xloc-x[i])*(xloc-x[i])+(yloc-y[i])*(yloc-y[i]),0.5)
                    if i == ic and test_particle==1:
                        print("CHECK 2 %d %d %d z=%8.4e in [%8.4e; %8.4e] x==%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e"% (i, ii, jj, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[ii][jj], z[surf_id[ii][jj]]))
                        
#                    if z[i] > surf_d[ii][jj] and dist <= rloc[i] and tau[i] >= tau_skip and flux[i] > pow(10, min_value-1):
                    if z[i] > surf_d[ii][jj] and dist <= rloc[i] and tau[i] >= tau_skip:
                    #if z[i] > surf_d[ii][jj] and dist <= rloc[i]:
                        ray_id[ii][jj][ray_n[ii][jj]]=i
                        ray_n[ii][jj]=ray_n[ii][jj]+1
                        if tau[i] < tau_min:
                            tau_min=tau[i]
                        if flux[i] < flux_min:
                            flux_min=flux[i]
                        if flux[i] > flux_max:
                            flux_max=flux[i]

                        if ii == itr and jj==jtr and test_ray==1:
                            print("adding a ray to %d %d  count=%d  %d tau=%8.4e flux=%8.4e  z=%8.4e"%(ii,jj,ray_n[ii][jj],i,tau[i],flux[i],z[i]))

    max_ray=0
    i_maxray=0
    j_maxray=0
    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            if ray_n[ii][jj] > max_ray:
                max_ray=ray_n[ii][jj]
                i_maxray=ii
                j_maxray=jj

    print("maximum number of particles above the cut off optically thick surface is %d %d %d"%(max_ray,i_maxray,j_maxray))            
    print("minimum tau account for is   %f"%(tau_min))            
    print("minimum flux account for is  %le"%(flux_min))            
    print("maximum flux account for is  %le"%(flux_max))            


    # this sorting is as simple as hell 
    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            if ray_n[ii][jj] > 1:
                #print("ray as %d %d  r_max=%d surface=%8.4e"%(ii,jj,ray_n[ii][jj],surf_d[ii][jj]))
                for kk in range(0, ray_n[ii][jj]):
                    swap=0
                    for ri in range(0, ray_n[ii][jj]-1):
                        ir1=ray_id[ii][jj][ri]
                        ir2=ray_id[ii][jj][ri+1]
                        if ir1==0 or ir2 ==0:
                            print("ray to the core? %d %d", ii, jj)
                            exit()
                        if z[ir1] > z[ir2]:
                            ray_id[ii][jj][ri]=ir2
                            ray_id[ii][jj][ri+1]=ir1
                            swap=swap+1
                    if swap == 0:
                        break
                if swap > 0:
                    print("Did not complete sorting")
                    exit()


    if test_ray == 1:
        print("ray outwards")  
        print("surface at %d %d   id=%d  z=%e"%(itr,jtr,surf_id[itr][jtr], z[surf_id[itr][jtr]]))
        if ray_n[itr][jtr] > 0:      
            for ri in range(0, ray_n[itr,jtr]):                
                print("ray at %d %d  id=%d  number of rays %d"%(itr,jtr,ray_id[itr][jtr][ri],ray_n[itr,jtr]))
                print("ray backwards")  
        if ray_n[itr][jtr] > 0:      
            for ri in range(ray_n[itr,jtr]-1, -1, -1):
                print("ray at %d %d  id=%d"%(itr,jtr,ray_id[itr][jtr][ri]))
                print("surface at %d %d   id=%d  number of rays %d"%(itr,jtr,surf_id[itr][jtr],ray_n[itr,jtr]))

                

    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            i=surf_id[ii][jj]
            surf_br[ii][jj] = 0            
            tau_ray=0.    
            if ray_n[ii][jj] > 0:
                #print("ray as %d %d  r_max=%d surface=%8.4e"%(ii,jj,ray_n[ii][jj],surf_d[ii][jj]))
                for ri in range(ray_n[ii,jj]-1, -1, -1):
                    ir = ray_id[ii,jj][ri]
                    surf_br[ii,jj] += flux[ir] * np.exp(-tau_ray)
                    vel_flux+=flux[ir] * np.exp(-tau_ray)*vz[ir]
                    b_full= sigma_const/pi_const*pow(teff[ir],4.)
                    
                    if t_max < teff[ir] :
                        t_max=teff[ir]
                                            
                    for j in range (0,n_l):
                        expon=factor2/teff[ir]/lam[j]
                        if expon < 150:
                            b_l[j] = factor1/pow(lam[j],5.)/(math.exp(expon)-1.0)
                        else:
                            b_l[j] = 0.
                        spectrum[j]=spectrum[j]+flux[ir] * np.exp(-tau_ray) * (b_l[j] / b_full)   
                            
                        
                    if test_ray == 1 and ii==itr and jj==jtr:
                        print("brigntess modification backward %d  br=%e flux_loc=%e tau_t=%e tau_l=%e   z=%e in [%e,%e] x=%e y=%e"%(ir, surf_br[ii,jj],flux[ir],tau_ray,tau[ir],z[ir],z[ir]-4./3.*h[ir],z[ir]+4./3.*h[ir], x[ir],y[ir]))
                        
                    tau_ray += tau[ir]           

                        
            i=surf_id[ii][jj]
            if i > 0:
                surf_br[ii,jj] += flux[i] * np.exp(-tau_ray)
                vel_flux+=flux[i] * np.exp(-tau_ray)*vz[i]
                
                for j in range (0,n_l):
                    expon=factor2/teff[i]/lam[j]
                    b_full= sigma_const/pi_const*pow(teff[i],4.)
                    if expon < 150:
                        b_l[j] = factor1/pow(lam[j],5.)/(math.exp(expon)-1.0)
                    else:
                        b_l[j] = 0.
                        
                    spectrum[j]=spectrum[j]+flux[i] * np.exp(-tau_ray) * (b_l[j] / b_full)   
                
                if test_ray == 1 and ii==itr and jj==jtr:
                    print("brigntess modification finishes at %d %e %e %e  tau_tot=%e   z=%e in [%e;%e]  x=%e y=%e"%(i, surf_br[ii,jj],flux[i],tau_ray,tau[i],z[i],z[i]-4./3.*h[i],z[i]+4./3.*h[i],x[i],y[i]))
                    
    print("rays sorting is completed")
    print("maximum observed Teff", t_max)

    surf_bmax=0.
    ii_max=0
    jj_max=0

    for ii in range(0,n_res-2):
        for jj in range(0,n_res-2):
            if surf_br[ii][jj] > surf_bmax:
                surf_bmax= surf_br[ii][jj]
                ii_max=ii
                jj_max=jj

    print("max brigntess %e %d %d %d"%(surf_bmax, ii_max, jj_max,ray_n[ii_max][jj_max]))

                
    if test_ray == 1:
        print("final brigntess at tested ray is %e "%(surf_br[itr,jtr]))

    flux_tot=0.
        
    for ii in range(0,n_res-2):
        for jj in range(0,n_res-2):
            area_br = (surf_br[ii][jj] + surf_br[ii][jj+1] + surf_br[ii+1][jj] + surf_br[ii+1][jj+1])/4.
            
            teff_loc = pow(area_br/sigma_const,0.25)
            
            surf_t[ii][jj]=teff_loc*area_br            
            #if teff_loc > 4000:
            #    print("check local T=%e  flux=%e"%(teff_loc, area_br))

            flux_tot=flux_tot+area_br   
            ltot=ltot+area_br


                
    teff_aver=0.
    for ii in range(0,n_res-2):
        for jj in range(0,n_res-2):
            surf_t[ii][jj]=surf_t[ii][jj]/ltot
            teff_aver=teff_aver+surf_t[ii][jj]

    vel_flux=vel_flux/flux_tot
            
    
    teff_spectrum=0.
    teff_min=0.
    teff_max=0.
    max_flux=-10.
    il_flux=0
    ltot_spectrum=0.    
    lv_spectrum=0.
    lr_spectrum=0.
    li_spectrum=0.

    for il in range (il_max-1):
        sp=spectrum[il]
        ltot_spectrum=ltot_spectrum+spectrum[il]*dl*nanom
        if sp > 0:
            sp=np.log10(sp)
            lamb=lam[il]/nanom
            teff_loc= 2.9*1.e6/lamb
            if sp > max_flux:
                max_flux=sp
                il_flux=il
                teff_spectrum=teff_loc
            if lamb >= 500 and lamb <=600:
                lv_spectrum=lv_spectrum+spectrum[il]*dl*nanom
            if lamb >= 590 and lamb <=730:
                lr_spectrum=lr_spectrum+spectrum[il]*dl*nanom
            if lamb >= 720 and lamb <=880:
                li_spectrum=li_spectrum+spectrum[il]*dl*nanom

                
    teff_min=teff_spectrum
    teff_max=teff_spectrum
    min_flux=0.95*pow(10,max_flux)
    
    for il in range (il_flux,1,-1):
        sp=spectrum[il]
        if sp >= min_flux:
            lamb=lam[il]/nanom
            teff_loc= 2.9*1.e6/lamb
            teff_max=teff_loc
        if sp < min_flux:
            break
        
    for il in range (il_flux,il_max-1):
        sp=spectrum[il]
        if sp >= min_flux:
            lamb=lam[il]/nanom
            teff_loc= 2.9*1.e6/lamb
            teff_min=teff_loc
        if sp < min_flux:
            break
        
    spectrum_output = []
    b_full= sigma_const/pi_const*pow(teff_spectrum,4.)
    for il in range (il_max-1):
        sp=spectrum[il]
        
        if sp > 0:
            sp=np.log10(sp)
            lamb=lam[il]/nanom
            teff_loc= 2.9*1.e6/lamb
            expon=factor2/teff_spectrum/lam[il]
            if expon < 150:
                b_l[il] = factor1/pow(lam[il],5.)/(math.exp(expon)-1.0)
            else:
                b_l[il] = 0.
            spectrum_output += [[il, lamb, teff_loc, sp, b_l[il]]]
            
            
    print("Total flux=%le ltot=%le "%(flux_tot,ltot))
    print("Teff=%8.2f  Teff_min=%8.2f   Teff_max=%8.2f"%(teff_spectrum, teff_min, teff_max))
    print("Average velocity=%le "%(vel_flux))
            
    ltot=ltot*dx*dy*rsun*rsun
    ltot_spectrum=ltot_spectrum*dx*dy*rsun*rsun
    lv_spectrum=lv_spectrum*dx*dy*rsun*rsun
    lr_spectrum=lr_spectrum*dx*dy*rsun*rsun
    li_spectrum=li_spectrum*dx*dy*rsun*rsun
    print("Check luminosities ltot=%le ltot_spectrum=%le "%(ltot,ltot_spectrum))


    Lcool=0.
    Lheat=0.
    Lurad=0.
    for i in range(1,ntot,1):
        Lcool=Lcool+uraddotcool[i]*m[i]
        Lheat=Lheat+uraddotheat[i]*m[i]
        Lurad=Lurad+uraddot[i]*m[i]

    ltot*=4
    ltot_spectrum*=4
    lv_spectrum*=4
    lr_spectrum*=4
    li_spectrum*=4
    Lcool*=msun
    Lheat*=msun
    Lurad*=msun
    
    print("Total L %12.4E "% ltot)
    print("V L  %12.4E "% lv_spectrum)
    print("R L  %12.4E "% lr_spectrum)
    print("I L  %12.4E "% li_spectrum)
    print("Cooling L %12.4E "% Lcool)
    print("Heating L %12.4E "% Lheat)
    print("udot L %12.4E "% Lurad)

    #teff_aver=teff_spectrum
    l_v=lv_spectrum
    l_r=lr_spectrum
    l_i=li_spectrum
    rad_eff = pow(ltot/pi_const/sigma_const/pow(teff_aver,4),0.5)/rsun
    print("Effective radius %e"%rad_eff)
    return time,ltot,l_v,l_r,l_i,teff_aver,teff_spectrum,rad_eff,surf_br,surf_d,surf_id,surf_t,ray_n,dx,dy,flux_tot,spectrum_output,xmin,xmax,ymin,ymax,ltot_spectrum,flux,teff,kappa,tau,rloc,teff_min,teff_max
 

    ###
    ###

    

def rotate(x,y,z,anglexdeg,angleydeg,anglezdeg):
    if isinstance(x, (float,int)): x = [x]
    if isinstance(y, (float,int)): y = [y]
    if isinstance(z, (float,int)): z = [z]

    if not isinstance(x,np.ndarray): x = np.array(x)
    if not isinstance(y,np.ndarray): y = np.array(y)
    if not isinstance(z,np.ndarray): z = np.array(z)

    xangle = float(360-anglexdeg)/180.*np.pi
    yangle = float(360-angleydeg)/180.*np.pi
    zangle = float(360-anglezdeg)/180.*np.pi

    if zangle != 0: # rotate about z
        rold = np.sqrt(x*x + y*y)
        phi = np.arctan2(y,x)
        phi -= zangle
        x = rold*np.cos(phi)
        y = rold*np.sin(phi)
    if yangle != 0: # rotate about y
        rold = np.sqrt(z*z + x*x)
        phi = np.arctan2(z,x)
        phi -= yangle
        z = rold*np.sin(phi)
        x = rold*np.cos(phi)
    if xangle != 0: # rotate about x
        rold = np.sqrt(y*y + z*z)
        phi = np.arctan2(z,y)
        phi -= xangle
        y = rold*np.cos(phi)
        z = rold*np.sin(phi)

    return x, y, z
