"""
Create a few FluxResult objects and one FluxResults object for testing.
"""

def get_fluxresult_details():
    """ Check the file named test_fluxresult.py in the directory above for the
    expected arguments to the FluxFinder and FluxResult. """
    import fluxresult_details
    yield from fluxresult_details.fluxresult_details

def get_fluxresults_details():
    """ Check the file named test_fluxresult.py in the directory above for the
    expected arguments to the FluxResults. """
    import fluxresult_details
    yield from fluxresult_details.fluxresults_details

if __name__ == '__main__':
    import starsmashertools
    import starsmashertools.lib.flux
    
    simulation = starsmashertools.get_simulation('.')
    output = simulation.get_output(0)
    
    for details in get_fluxresult_details():
        finder = starsmashertools.lib.flux.FluxFinder(output, **details['kwargs'])
        finder.get()
        finder.result.save(details['filename'], allowed = details['allowed'])
        print("Created '%s'" % details['filename'])

    # Now save a few FluxResults objects for testing
    for details in get_fluxresults_details():
        results = starsmashertools.lib.flux.FluxResults(allowed = details['allowed'])
        for result in details['FluxResult']:
            results.add(result)
        
        results.save(details['filename'])
        print("Created '%s'" % details['filename'])
