if __name__ == '__main__':
    import flux_main
    import starsmashertools
    import numpy as np
    import os
    import copy
    
    simulation = starsmashertools.get_simulation('.')
    output = simulation.get_output()

    def make(name, inputs):
        result = flux_main.flux_to_observer(output, *inputs)

        time,ltot,l_v,l_r,teff_aver,teff_spectrum,rad_eff,surf_br,surf_br_v,surf_d,surf_id,surf_t,ray_n,dx,dy,flux_tot,spectrum_output,xmin,xmax,ymin,ymax,ltot_spectrum,l_spectrum,flux,teff,kappa,tau,rloc = result

        inputs = np.asarray(inputs, dtype = float)
        spectrum_output = np.asarray(spectrum_output)

        outputs = np.asarray(
            [time, ltot, l_v, l_r, teff_aver,teff_spectrum, rad_eff, xmin,xmax,ymin,ymax, dx,dy,flux_tot,ltot_spectrum, l_spectrum['V'], l_spectrum['R']],
            dtype = float,
        )

        # Save the results to file
        np.savez_compressed(
            name, # saves to name.npz
            input_file = np.asarray([os.path.basename(output.path)], dtype=str),
            inputs = inputs,
            outputs = outputs,
            surf_br = surf_br,
            surf_br_v = surf_br_v,
            surf_d = surf_d,
            surf_id = surf_id,
            surf_t = surf_t,
            ray_n = ray_n,
            particle_flux = flux,
            particle_teff = teff,
            particle_kappa = kappa,
            particle_tau = tau,
            particle_rloc = rloc,
            spectrum_output = spectrum_output,
        )

    idx = {
        'n_res' : 0,
        'min_value' : 1,
        'max_value' : 2,
        'xmin' : 3,
        'xmax' : 4,
        'ymin' : 5,
        'ymax' : 6,
        'do_domain' : 7,
        'theta' : 8,
        'phi' : 9,
        'tau_s' : 10,
        'tau_skip' : 11,
        'teff_cut' : 12,
        'do_fluffy' : 13,
        'do_dust' : 14,
    }
    orig_inputs = [
        17, # n_res
        2, # min_value
        12, # max_value
        np.inf, # xmin
        -np.inf, # xmax
        np.inf, # ymin
        -np.inf, # ymax
        1, # do_domain
        0, # theta
        0, # phi
        20, # tau_s
        1e-5, # tau_skip
        3500, # teff_cut
        0, # do_fluffy
        1, # do_dust
    ]

    inputs = copy.deepcopy(orig_inputs)
    make('simple', inputs)

    inputs[idx['theta']] = 45
    inputs[idx['phi']] = 30
    make('angles', inputs)

    inputs = copy.deepcopy(orig_inputs)
    inputs[idx['xmin']] = -100
    inputs[idx['xmax']] = 150
    inputs[idx['ymin']] = -600
    inputs[idx['ymax']] = 852
    inputs[idx['do_domain']] = 0
    make('extents', inputs)

    inputs = copy.deepcopy(orig_inputs)
    inputs[idx['do_dust']] = 0
    make('dustless', inputs)

    inputs = copy.deepcopy(orig_inputs)
    inputs[idx['do_fluffy']] = 1
    make('fluffy', inputs)

    inputs = copy.deepcopy(orig_inputs)
    inputs[idx['tau_s']] = 100
    make('tau_s', inputs)

    inputs = copy.deepcopy(orig_inputs)
    inputs[idx['teff_cut']] = 100
    make('teff_cut', inputs)

    inputs = copy.deepcopy(orig_inputs)
    inputs[idx['tau_skip']] = 0
    make('tau_skip_low', inputs)

    
    inputs[idx['tau_skip']] = 5
    make('tau_skip_high', inputs)
