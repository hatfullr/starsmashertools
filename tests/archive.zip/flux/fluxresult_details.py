""" These are the keyword arguments which will be used when creating the 
FluxResult objects in tests/flux/make_fluxresult.py. """
fluxresult_details = [
    {
        'filename' : 'fluxresult0.zip',
        'kwargs' : { 'resolution' : (10,10), 'theta' :  0, 'phi' :  0 },
        'allowed' : { 'kwargs' : True, 'simulation' : True, 'time' : True },
    },
    {
        'filename' : 'fluxresult1.zip',
        'kwargs' : { 'resolution' : (10,10), 'theta' : 45, 'phi' :  0 },
        'allowed' : { 'kwargs' : True, 'simulation' : True, 'time' : True },
    },
    {
        'filename' : 'fluxresult2.zip',
        'kwargs' : { 'resolution' : (10,10), 'theta' : 45, 'phi' : 45 },
        'allowed' : { 'kwargs' : True, 'simulation' : True, 'time' : True },
    },
]

fluxresults_details = [
    {
        # Testing saving multiple FluxResult
        'filename' : 'fluxresults0.zip',
        'FluxResult' : ['fluxresult0.zip', 'fluxresult1.zip', 'fluxresult2.zip'],
        'allowed' : { 'kwargs' : True, 'simulation' : True, 'time' : True },
    },
    {
        # Testing saving single FluxResult. Should result in a FluxResults
        # archive with only a single stored value.
        'filename' : 'fluxresults1.zip',
        'FluxResult' : ['fluxresult0.zip'],
        'allowed' : { 'kwargs' : True, 'simulation' : True, 'time' : True },
    },
    {
        # Testing the 'allowed' argument to the FluxResults constructor. Only
        # the 'time' parameter should be saved in the archive.
        'filename' : 'fluxresults2.zip',
        'FluxResult' : ['fluxresult0.zip'],
        'allowed' : { 'time' : True },
    },
]
