
def create():
    import starsmashertools.lib.archive
    import starsmashertools.helpers.jsonfile
    import starsmashertools.lib.units
    import datetime
    import numpy as np

    now = datetime.datetime.now()
    date = datetime.datetime.date(now)
    time = datetime.datetime.time(now)

    filename = '{day:02d}{month:02d}{year:04d}_{hour:02d}{minute:02d}{second:02d}.zip'.format(
        day = date.day,
        month = date.month,
        year = date.year,
        hour = time.hour,
        minute = time.minute,
        second = time.second,
    )
    
    archive = starsmashertools.lib.archive.Archive(
        filename,
        auto_save = False,
        replacement_flags = [],
    )

    for _kind in starsmashertools.helpers.jsonfile.serializable_types:
        print("Adding", _kind)
        if _kind == type(None):
            archive.add(
                'None',
                None,
            )
        elif _kind == np.ndarray:
            archive.add(
                _kind.__name__,
                _kind((1,)),
            )
        elif _kind == starsmashertools.lib.units.Unit:
            archive.add(
                _kind.__name__,
                _kind(1., 's'),
            )
        else:
            archive.add(
                _kind.__name__,
                _kind(),
            )

    archive.save()
    

if __name__ == '__main__':
    create()
