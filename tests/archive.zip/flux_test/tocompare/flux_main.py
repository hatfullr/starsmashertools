import starsmashertools
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.path import Path
import matplotlib.colors as colors
import matplotlib.cm as cm
import matplotlib.patches as patches
from matplotlib import rc
import math
import sys, getopt
from matplotlib.colors import BoundaryNorm
import numpy as np
import argparse
import pylab
import matplotlib as mpl
import flux_tools
import flux_main
import matplotlib.colorbar
from mpl_toolkits.axes_grid1 import make_axes_locatable



def flux_to_observer(dir_name: str, sph_name: str
            , min_value: float
            , max_value: float
            , xmin: float, xmax: float
            , ymin: float, ymax: float
            , do_domain: int
            , theta: float, phi: float
            , tau_s: float, tau_skip: float
            , teff_cut: float
            , do_fluffy:int, do_dust:int
            , test_ray: int, itr: int, jtr:int
            , test_particle: int, ic: int
            , plot_name: str):
    
    #--------------------------------------------------
    #--------------------------------------------------
    from matplotlib import figure
    plt.rc('text', usetex=True)
    plt.rc('text.latex', preamble=r'\usepackage{amssymb}')
    plt.rc('font', family='serif')
    plt.rc('font', size=14)
    #-----------------------------------------------------
    plt.close('all')

    do_rays=1
    
    lwghta = 1.5
    lwght = 2.5 # starting line-weight
    hwght = 4.0
    #fig = plt.figure(figsize=(7.25, 6))
    fig, ax = plt.subplots(figsize=(7.25, 6), layout='constrained')

    #number of colors
    number_of_bins=50
    n_res=401
    
    name_cmap='Spectral'
    name_cmap='viridis'
    cmap_loc = plt.get_cmap(name_cmap)  ## try also jet, hsv and gist_rainbow and RdBu, PuOr,PrGn (white in the middle)
    cNorm  = colors.Normalize(vmin=min_value, vmax=max_value)
    scalarMap = cm.ScalarMappable(norm=cNorm, cmap=cmap_loc)
    v_label="Flux [erg/s/cm2]"
    
        
    # astronomical constants
    rsun=6.9599e10
    msun=1.9891e33
    lsun=3.89e33
    c_speed=2.99792458e10 #2.99e10
    a_const=7.565767e-15 # cgs #7.5646e-15
    gas_const=8.3144598e7
    mu_ion = 0.617283950617284
    pi_const=math.pi
    sigma_const=5.6704e-5
    
    T_dust=1000.0
    T_dust_min=100.0
    kappa_dust=1.0

    time=0
    ltot=0
    l_v=0
    teff_aver=0
    rad_eff=0
    flag_return=1
    Lcool=0.
    Lheat=0.

    #===== common initializing/data file reading part 
    simulation = starsmashertools.get_simulation(dir_name)

    #n_sim = len(simulation.get_output())
    #id_sim=-1
    #
    #for i in range (0, n_sim,1):
    #    s1=str(simulation.get_output(i))
    #    s2=s1[8:19]
    #    #print("string varaible", s2, sph_name)
    #    if s2 == sph_name:
    #        id_sim=i
    #        break
    #
    #
    #print("number of simulations", n_sim, id_sim)
    #if id_sim == -1:
    #    print("simulation is not present, skipping", sph_name)
    #    flag_return=0
    #    return [time,(ltot*4.),(l_v*4.),teff_aver,rad_eff,Lcool, Lheat,flag_return]
    #
    #current = simulation.get_output(id_sim)
    #print("using simulation", simulation.get_output(id_sim),flag_return)

    current = starsmashertools.lib.output.Output(sph_name, simulation)

    # in case, to  ake sure we use the same units
    msun=float(simulation.units['am'])
    rsun=float(simulation.units['x'])
    
    ntot = current['ntot']
    time=current['t'] * float(simulation.units['t'])/24./3600.
    rho = current['rho'] * float(simulation.units['rho'])
    m = current['am']
    h = current['hp']
    rho = current['rho'] * float(simulation.units['rho'])
    u = current['u'] * float(simulation.units['u'])
    uraddot = current['uraddot'] * float(simulation.units['uraddot'])
    uraddotcool = current['uraddotcool'] * float(simulation.units['uraddotcool'])
    uraddotheat = current['uraddotheat'] * float(simulation.units['uraddotheat'])
    uraddot_emerg = current['dEemergdt'] * float(simulation.units['dEemergdt'])
    uraddot_diff = current['dEdiffdt'] * float(simulation.units['dEdiffdt'])
    kappa = current['popacity'] * float(simulation.units['popacity'])
    tau = current['tau']
    temp = current['temperatures']    
    rloc=current['x']
    x=current['x']
    y=current['y']
    z=current['z']
    id=current['ID']

    #======

    x,y,z = flux_tools.rotate(x,y,z,theta,0,phi)

    print("fname: %20s" % sph_name)
    print("min_value: %12.5f" % min_value)
    print("max_value: %12.5f" % max_value)

    if do_domain != 1:
        print("xmin: %12.5f" % xmin)
        print("xmax: %12.5f" % xmax)
        print("ymin: %12.5f" % ymin)
        print("ymax: %12.5f" % ymax)

    if do_domain == 1:
        rloc_arr = (0.75*m*msun/(pi_const*rho))**0.33333/rsun
        if do_fluffy == 1:
            rloc_arr = 2.*h
        xmin = np.amin(x - rloc_arr)
        xmax = np.amax(x + rloc_arr)
        ymin = np.amin(y - rloc_arr)
        ymax = np.amax(y + rloc_arr)

        max_coord=max(abs(xmin),abs(xmax), abs(ymin), abs(ymax))
        xmax=max_coord
        ymax=max_coord
        ymin=-max_coord
        xmin=-max_coord    
        print("domain  max: %12.5f" %  max_coord)


    ltot=0.
    l_v=0.
    l_ir=0.

    print("Time = %4f" % time)
    plot_title =  "Time = " +format(time, '4.1f') + " days"
    print("Doing plot titles %s" % plot_title)

    rows=n_res
    cols=n_res

    surf_d = np.zeros((rows,cols))
    surf_id = np.zeros((rows,cols),dtype=int)
    surf_br = np.zeros((rows,cols))
    surf_br_v = np.zeros((rows,cols))
    surf_t = np.zeros((rows,cols))
    flux=np.zeros(200000)
    teff=np.zeros(200000)
    ray_id =  np.zeros((rows,cols,600),dtype=int)
    ray_n =  np.zeros((rows,cols),dtype=int)

    for i in range(0,n_res-1):
        for j in range(0,n_res-1):
            surf_id[i][j]=-1
            surf_d[i][j]=-1.e30
            surf_t[i][j]=0.

    dx = (xmax-xmin)/(n_res-1)
    dy = (ymax-ymin)/(n_res-1)

    print("dx=%f dy=%f"%(dx,dy))
    
    Lcool=0.
    Lheat=0.
    Lurad=0.
        
    for i in range(1, ntot-1):

        iloc = math.floor((x[i]-xmin)/dx)
        jloc = math.floor((y[i]-ymin)/dy)

        if temp[i] < T_dust and temp[i] > T_dust_min and kappa[i] < kappa_dust and do_dust == 1:
            kappa[i]=kappa_dust

        if uraddot_emerg[i] < uraddot_diff[i] and do_fluffy == 1:
            # this particle is considered in "fluffy" approximation
            rloc[i]=2.*h[i]
            rhoold=rho[i]
            rho[i]=m[i]*msun/pow(rloc[i]*rsun,3.)
            #kappa[i]=kappa[i]*rho[i]/rhoold
            #if temp[i] < 1000 and kappa[i] < 1 and do_dust == 1:
            #    kappa[i]=1.0
            tau[i]=rho[i]*kappa[i]*rloc[i]*rsun*4./3.
            flux_em = uraddot_emerg[i]/4./pi_const/rloc[i]/rloc[i]/rsun/rsun
            flux[i]=flux_em
            #print("Treat fluffy %d %f %f %f %f %f"%(i, kappa[i], temp[i], tau[i], flux[i], rloc[i]))           
 
        else :
            # this particle is considered in "dense" approximation 
            rloc[i]=pow(m[i]*msun/(4/3.*pi_const)/rho[i],0.33333)/rsun
            tau[i]=rho[i]*kappa[i]*rloc[i]*rsun*4./3.
            ad      = 4.*pi_const*rloc[i]*rloc[i]*rsun*rsun
            ad_cool = 2.*pi_const*rloc[i]*rloc[i]*rsun*rsun
            flux_em = uraddot_emerg[i]/ad
            dd=c_speed/kappa[i]/rho[i]
            tdiffloc=kappa[i]*rho[i]*rloc[i]*rloc[i]*rsun*rsun/c_speed
            gradt=a_const*pow(temp[i],4)/rloc[i]/rsun
            dedt=ad/3.*dd*gradt/m[i]/msun
            flux[i]=dedt*m[i]*msun/ad
            flux_cool=-uraddotcool[i]*m[i]*msun/ad
            ratio = -uraddotcool[i]/dedt*12. # to figure out how many effective cooling rays
            if do_rays == 1:
                if ratio <= 6: # all what is cooling it, goes through the outer hemisphere
                    flux[i]=-uraddotcool[i]*m[i]*msun/ad_cool # all what is cooled is to goes through the outer hemisphere
                if ratio > 6: # the particle is getting cooled also to the back, but cools at max through the outer hemisphere
                    flux[i]=dedt*m[i]*msun/ad

            if id[i] == 54996:
                print(" trace  %10.4e  %10.4e %10.4e %10.4e %10.4e %10.4e %10.4e %6f"%(uraddot_emerg[i], uraddot_diff[i], uraddot_diff[i]/uraddot_emerg[i], flux_em, flux[i], flux_cool,flux[i]/flux_em, ratio))

            flux[i]=min(flux[i],flux_em)
            #if min(uraddot_emerg[i],uraddot_diff[i]) > 1.e36:
            #    conv=4.*pi_const*rsun*rsun*rloc[i]*rloc[i]/lsun
            #    flag_diff=0
            #    if uraddot_emerg[i] > uraddot_diff[i]:
            #        flag_diff=1
            #    print("Energies %d %d em=%10.4e diff=%10.4e tot=%10.4e fc=%10.4e flux=%10.4e  tau=%10.4e  ratio=%4f"%(id[i], flag_diff, uraddot_emerg[i]/lsun,uraddot_diff[i]/lsun, uraddotcool[i]*m[i]*msun/lsun/conv,flux_cool, flux[i],tau[i], ratio))
        
        teff[i]=pow(flux[i]/sigma_const,0.25)


        if i == ic and test_particle==1:
            print("%d z=%8.4e in [%8.4e; %8.4e] %8.4e "% (i, z[i], z[i]-rloc, z[i]+rloc[i], tau[i]))


        if iloc >= 0 and iloc <= (n_res-1) and jloc >=0 and jloc <=(n_res-1):
            if tau[i] >=  tau_s and z[i] > surf_d[iloc][jloc] :

                imin = max(math.floor((x[i]-rloc[i]-xmin)/dx),0)
                imax = min(math.ceil((x[i]+rloc[i]-xmin)/dx),n_res-1)
                jmin = max(math.floor((y[i]-rloc[i]-ymin)/dy),0)
                jmax = min(math.ceil((y[i]+rloc[i]-ymin)/dy), n_res-1)

                for ii in range(imin,imax):
                    for jj in range(jmin,jmax):
                        xloc=xmin+dx*ii
                        yloc=ymin+dy*jj
                        dist=pow( (xloc-x[i])*(xloc-x[i])+(yloc-y[i])*(yloc-y[i]),0.5)
                        if test_ray == 1 and ii==itr and jj==jtr:
                            print("consider ray to %d %d  id=%d z=%8.4e tau=%8.4e    %e %e"%(itr,jtr,surf_id[itr][jtr],surf_d[itr][jtr],tau[surf_id[itr][jtr]], xloc,yloc))
                        
                        if z[i] > surf_d[ii][jj] and dist <= rloc[i]:
                            surf_d[ii][jj]=z[i]
                            surf_id[ii][jj]=i


    if test_ray == 1:
        print("created a ray to %d %d  id=%d z=%8.4e tau=%8.4e    %e %e"%(itr,jtr,surf_id[itr][jtr],surf_d[itr][jtr],tau[surf_id[itr][jtr]], xmin+dx*itr,ymin+dy*jtr))
        #exit()

    tau_min=1

    for i in range(0, ntot-1):

        iloc = math.floor((x[i]-xmin)/dx)
        jloc = math.floor((y[i]-ymin)/dy)

        if i == ic and test_particle==1:
            print("CHECK 0 %d %d %d z=%8.4e in [%8.4e; %8.4e] x=%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e %d"% (i, iloc, jloc, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[iloc][jloc], z[surf_id[iloc][jloc]], surf_id[iloc][jloc]))

        if iloc >= 0 and iloc <= (n_res-1) and jloc >=0 and jloc <=(n_res-1) :

            imin = max(math.floor((x[i]-rloc[i]-xmin)/dx),0)
            imax = min(math.ceil((x[i]+rloc[i]-xmin)/dx),n_res-1)
            jmin = max(math.floor((y[i]-rloc[i]-ymin)/dy),0)
            jmax = min(math.ceil((y[i]+rloc[i]-ymin)/dy), n_res-1)
            
            if i == ic and test_particle==1:
                print("CHECK 1 %d %d %d %d %d z=%8.4e in [%8.4e; %8.4e] x==%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e"% (i, imin, imax, jmin, jmax, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[ii][jj], z[surf_id[ii][jj]]))
                
            for ii in range(imin,imax):
                for jj in range(jmin,jmax):
                    xloc=xmin+dx*ii
                    yloc=ymin+dy*jj
                    dist=pow( (xloc-x[i])*(xloc-x[i])+(yloc-y[i])*(yloc-y[i]),0.5)
                    if i == ic and test_particle==1:
                        print("CHECK 2 %d %d %d z=%8.4e in [%8.4e; %8.4e] x==%8.4e y=%8.4e tau=%8.4e surface=%8.4e %8.4e"% (i, ii, jj, z[i], z[i]-rloc[i], z[i]+rloc[i], x[i], y[i], tau[i],  surf_d[ii][jj], z[surf_id[ii][jj]]))
                    if z[i] > surf_d[ii][jj] and dist <= rloc[i] and tau[i] >= tau_skip:
                        ray_id[ii][jj][ray_n[ii][jj]]=i
                        ray_n[ii][jj]=ray_n[ii][jj]+1
                        if tau[i] < tau_min:
                            tau_min=tau[i]
                        if ii == itr and jj==jtr and test_ray==1:
                            print("adding a ray to %d %d  count=%d  %d tau=%8.4e"%(ii,jj,ray_n[ii][jj],i,tau[i]))

    max_ray=0
    i_maxray=0
    j_maxray=0
    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            if ray_n[ii][jj] > max_ray:
                max_ray=ray_n[ii][jj]
                i_maxray=ii
                j_maxray=jj

    print("maximum number of particles above the cut off optically thick surface is %d %d %d"%(max_ray,i_maxray,j_maxray))            
    print("minimum tau account for is  is %f"%(tau_min))            


    # this sorting is as simple as hell 
    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            if ray_n[ii][jj] > 1:
                #print("ray as %d %d  r_max=%d surface=%8.4e"%(ii,jj,ray_n[ii][jj],surf_d[ii][jj]))
                for kk in range(0, ray_n[ii][jj]):
                    swap=0
                    for ri in range(0, ray_n[ii][jj]-1):
                        ir1=ray_id[ii][jj][ri]
                        ir2=ray_id[ii][jj][ri+1]
                        if ir1==0 or ir2 ==0:
                            print("ray to the core? %d %d", ii, jj)
                            exit()
                        if z[ir1] > z[ir2]:
                            ray_id[ii][jj][ri]=ir2
                            ray_id[ii][jj][ri+1]=ir1
                            swap=swap+1
                    if swap == 0:
                        break
                if swap > 0:
                    print("Did not complete sorting")
                    exit()


    if test_ray == 1:
        print("ray outwards")  
        print("surface at %d %d   id=%d  z=%e"%(itr,jtr,surf_id[itr][jtr], z[surf_id[itr][jtr]]))
        if ray_n[itr][jtr] > 0:      
            for ri in range(0, ray_n[itr,jtr]):                
                print("ray at %d %d  id=%d  number of rays %d"%(itr,jtr,ray_id[itr][jtr][ri],ray_n[itr,jtr]))
                print("ray backwards")  
        if ray_n[itr][jtr] > 0:      
            for ri in range(ray_n[itr,jtr]-1, -1, -1):
                print("ray at %d %d  id=%d"%(itr,jtr,ray_id[itr][jtr][ri]))
                print("surface at %d %d   id=%d  number of rays %d"%(itr,jtr,surf_id[itr][jtr],ray_n[itr,jtr]))


    for ii in range(0,n_res-1):
        for jj in range(0,n_res-1):
            i=surf_id[ii][jj]
            surf_br_v[ii][jj] = 0
            surf_br[ii][jj] = 0            
            tau_ray=0.    
            if ray_n[ii][jj] > 0:
                #print("ray as %d %d  r_max=%d surface=%8.4e"%(ii,jj,ray_n[ii][jj],surf_d[ii][jj]))
                for ri in range(ray_n[ii,jj]-1, -1, -1):
                    ir = ray_id[ii,jj][ri]
                    surf_br[ii,jj] += flux[ir] * np.exp(-tau_ray)
                    if test_ray == 1 and ii==itr and jj==jtr:
                        print("brigntess modification backward %d  br=%e flux_loc=%e tau_t=%e tau_l=%e   z=%e in [%e,%e] x=%e y=%e"%(ir, surf_br[ii,jj],flux[ir],tau_ray,tau[ir],z[ir],z[ir]-4./3.*h[ir],z[ir]+4./3.*h[ir], x[ir],y[ir]))
                    if teff[ir] > teff_cut:
                        surf_br_v[ii][jj]+=flux[ir] * np.exp(-tau_ray)
                        
                    tau_ray += tau[ir]           

                    if surf_br_v[ii][jj] >  surf_br[ii][jj]:
                        print("part of the flux is larger then whole flux?   %d %d %d %d   tau=%8.4e  %8.4e  %8.4e  %8.4e"%(ii,jj,ri,ir,tau[ir],surf_br[ii][jj],surf_br_v[ii][jj],flux[ir]))
                        exit()

            i=surf_id[ii][jj]
            if i > 0:
                surf_br[ii,jj] += flux[i] * np.exp(-tau_ray)
                if test_ray == 1 and ii==itr and jj==jtr:
                    print("brigntess modification finishes at %d %e %e %e  tau_tot=%e   z=%e in [%e;%e]  x=%e y=%e"%(i, surf_br[ii,jj],flux[i],tau_ray,tau[i],z[i],z[i]-4./3.*h[i],z[i]+4./3.*h[i],x[i],y[i]))
                if teff[i] > teff_cut:
                    surf_br_v[ii][jj] += flux[i]* np.exp(-tau_ray)

    print("rays sorting is completed")

    if test_ray == 1:
        print("final brigntess %e "%(surf_br[itr,jtr]))

    flux_tot=0.
        
    for ii in range(0,n_res-2):
        for jj in range(0,n_res-2):
            area_br = (surf_br[ii][jj] + surf_br[ii][jj+1] + surf_br[ii+1][jj] + surf_br[ii+1][jj+1])/4.
            
            teff_loc = pow(area_br/sigma_const,0.25)
            surf_t[ii][jj]=teff_loc*area_br            
#            if area_br > 5.e11:
#                print("check local T=%e  flux=%e"%(teff_loc, area_br))

            flux_tot=flux_tot+ area_br   
            var_den=np.log10(area_br+1.e-20)
            ltot=ltot+area_br
            l_v=l_v+surf_br_v[ii][jj]
            if var_den >= min_value:
                z_color = math.ceil(number_of_bins*(var_den-min_value)/(max_value-min_value))
                zz_color = (1./number_of_bins)*z_color*(max_value-min_value)+min_value
                colorVal = scalarMap.to_rgba(zz_color)           
                xloc=xmin+dx*ii
                yloc=ymin+dy*jj
                rect = patches.Rectangle((xloc, yloc), width=dx, height=dy, edgecolor='none', facecolor=colorVal)
                plt.gca().add_patch(rect)


                
    teff_aver=0.
    for ii in range(0,n_res-2):
        for jj in range(0,n_res-2):
            surf_t[ii][jj]=surf_t[ii][jj]/ltot
            teff_aver=teff_aver+surf_t[ii][jj]


    #teff_aver= (flux_tot / sigma_const)**0.25       
    print("Total flux %le "%(flux_tot))
    print("Averagef Teff %le "%(teff_aver))
            
    ltot=ltot*dx*dy*rsun*rsun/lsun
    l_v=l_v*dx*dy*rsun*rsun/lsun
    
    bounds = [-1, 2, 5, 7, 12, 15]
    norm = mpl.colors.BoundaryNorm(bounds, cmap_loc.N)
    fig.colorbar(mpl.cm.ScalarMappable(norm=cNorm, cmap=cmap_loc),
                 orientation='vertical',  
                 label=v_label,ax=ax)
    plt.axis('off')
    plt.axis('on')

    plt.axis([xmin, xmax, ymin,ymax])
    plt.xlabel(r"$x/R_\odot$", fontsize=16)    
    plt.ylabel(r"$y/R_\odot$", fontsize=16)

    plot_title = "Time = {:.2f}, L = {:.2f} Lsun, Teff = {:5.0f} K".format(time,ltot*4,teff_aver) 
    plt.title(plot_title, fontsize=14)        
    plt.savefig(plot_name, dpi=150)
    plt.close()
    plt.close('all')


    Lcool=0.
    Lheat=0.
    Lurad=0.
    for i in range(1,ntot,1):
        Lcool=Lcool+uraddotcool[i]*m[i]
        Lheat=Lheat+uraddotheat[i]*m[i]
        Lurad=Lurad+uraddot[i]*m[i]
    
    print("Total L %12.4E "% (ltot*4.))
    print("Visual L %12.4E "% (l_v*4.))
    print("Cooling L %12.4E "% (Lcool*msun/lsun))
    print("Heating L %12.4E "% (Lheat*msun/lsun))
    print("udot L %12.4E "% (Lurad*msun/lsun))

    rad_eff = pow(ltot*4.*lsun/pi_const/sigma_const/pow(teff_aver,4),0.5)/rsun
    print("Effective radius %e"%rad_eff)
    return [time,(ltot*4.),(l_v*4.),teff_aver,rad_eff,(Lcool*msun/lsun),(Lheat*msun/lsun),flag_return]
 

    ###
    ###

    
