if __name__ == '__main__':
    import flux_main
    import os

    curdir = os.path.dirname(__file__) # Directory of this file
    simdir = os.path.dirname(curdir) # Where my 'simulation' is located
    output_path = os.path.join(simdir, 'out1600.sph') # The full path to the output file
    
    flux_main.flux_to_observer(
        simdir, # dir_name
        output_path, # sph_name
        4,  # min_value ("-minv")
        15, # max_value ("-maxv")
        -1200, # xmin
        1200,  # xmax
        -1200, # ymin
        1200,  # ymax
        0,     # do_domain
        0.,    # theta
        0.,    # phi
        20.,   # tau_s
        1.e-5, # tau_skip
        3500,  # teff_cut
        0,     # do_fluffy
        0,     # do_dust
        0,     # test-ray
        130,   # itr
        100,   # jtr
        0,     # test_particle
        92282, # ic
        os.path.basename(output_path).replace('.sph', '.png'), # plot_name
    )
